package games.storeApp3.shopping;

public enum NameProduct {
    SOFA, CHAIR, CANDLESTICK;
}