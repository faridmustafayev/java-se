package games.storeApp.shopping;

import games.storeApp.enumProduct.NameProduct;
import games.storeApp.product.Product;

import java.util.HashMap;
import java.util.Map;

public class StoreImpl implements StoreApp {

    Map<NameProduct, Product> productMap;

    public StoreImpl() {
        productMap = new HashMap<>();
    }

    @Override
    public void buyProduct(NameProduct nameProduct, int count) {

        if (!productMap.containsKey(nameProduct)) {
            productMap.put(nameProduct, new Product(nameProduct.name(), count));
        }
        else {
            Product product = productMap.get(nameProduct);
            product.setCount(product.getCount() + count);
        }
    }

    @Override
    public void saleProduct(NameProduct nameProduct, int count) {

        if (productMap.containsKey(nameProduct)) {
            Product product = productMap.get(nameProduct);
            product.setCount(product.getCount() - count);
        }
        else {
            System.out.println("this product is out of stock .. ");
        }
    }

    @Override
    public void bossBuy() {
        buyProduct(NameProduct.SOFA, 13);
        buyProduct(NameProduct.CHAIR, 19);
        buyProduct(NameProduct.CANDLESTICK, 14);
    }

    @Override
    public void storageProduct() {
        System.out.println("My storage: ");
        productMap.forEach((e1, e2)-> System.out.println(e1 + " : " + e2));
    }
}