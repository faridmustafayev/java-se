package games.storeApp.kind;

import games.storeApp.product.Product;

public class Chair extends Product {
    public Chair(String name, int age) {
        super(name, age);
    }
}
