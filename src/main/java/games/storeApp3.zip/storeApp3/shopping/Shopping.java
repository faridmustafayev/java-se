package games.storeApp3.shopping;

public abstract class Shopping {
    public abstract void buyProductBoss(NameProduct nameProduct, int count);
    public abstract void purchasedBoss();
}