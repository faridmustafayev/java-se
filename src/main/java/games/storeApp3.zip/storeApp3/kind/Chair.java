package games.storeApp3.kind;

import games.storeApp3.product.Product;

public class Chair extends Product {
    public Chair(String name, int count) {
        super(name, count);
    }
}
