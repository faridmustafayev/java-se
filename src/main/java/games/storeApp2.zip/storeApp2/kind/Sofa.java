package games.storeApp2.kind;

import games.storeApp2.product.Product;

public class Sofa extends Product {
    public Sofa(String name, double weight, int count) {
        super(name, weight, count);
    }
}
