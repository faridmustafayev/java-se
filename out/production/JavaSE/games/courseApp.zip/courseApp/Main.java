package games.courseApp;

public class Main {
    public static void main(String[] args) {


        Registration.register();
        GroupInformation.information(Registration.groupStorage);



    }
}
