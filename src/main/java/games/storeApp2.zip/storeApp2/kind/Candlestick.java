package games.storeApp2.kind;

import games.storeApp2.product.Product;

public class Candlestick extends Product {

    public Candlestick(String name, double weight, int count) {
        super(name, weight, count);
    }
}
