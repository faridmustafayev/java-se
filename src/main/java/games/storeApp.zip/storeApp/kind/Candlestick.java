package games.storeApp.kind;

import games.storeApp.product.Product;

public class Candlestick extends Product {
    public Candlestick(String name, int age) {
        super(name, age);
    }
}
