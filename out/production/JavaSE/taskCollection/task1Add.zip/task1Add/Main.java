package taskCollection.task1Add;

public class Main {
    public static void main(String[] args) {

        StudentRegistration.register();

    }
}
