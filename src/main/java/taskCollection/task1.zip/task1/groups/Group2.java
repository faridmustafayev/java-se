package taskCollection.task1.groups;

public class Group2 {
    public String name;
    public int groupN;

    public Group2(String name, int groupN) {
        this.name = name;
        this.groupN = groupN;
    }

    @Override
    public String toString() {
        return "Group1{" +
                "name='" + name + '\'' +
                ", groupN=" + groupN +
                '}';
    }
}
