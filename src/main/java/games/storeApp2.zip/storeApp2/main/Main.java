package games.storeApp2.main;

import games.storeApp2.enumProduct.NameProduct;
import games.storeApp2.store.StoreApp;

public class Main {
    public static void main(String[] args) {

        StoreApp storeApp = new StoreApp();

        storeApp.buyProduct(NameProduct.SOFA, 200, 6);
        storeApp.buyProduct(NameProduct.SOFA, 200, 7);
        storeApp.buyProduct(NameProduct.CHAIR, 120, 5);
        storeApp.buyProduct(NameProduct.CANDLESTICK, 130, 8);

        storeApp.reportStorage();

        System.out.println("------------------------------------");
        System.out.println("------------------------------------");

        storeApp.saleProduct(NameProduct.CHAIR, 120, 3);

        storeApp.reportStorage();

    }
}
