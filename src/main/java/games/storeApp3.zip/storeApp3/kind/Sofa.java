package games.storeApp3.kind;

import games.storeApp3.product.Product;

public class Sofa extends Product {
    public Sofa(String name, int count) {
        super(name, count);
    }
}
