package games.storeApp2.store;

import games.storeApp2.enumProduct.NameProduct;
import games.storeApp2.product.Product;

import java.util.HashMap;
import java.util.Map;

public class StoreApp {

    Map<NameProduct, Product> productMap;
    public StoreApp() {
        productMap = new HashMap<>();
    }
    public void buyProduct(NameProduct nameProduct, double weight, int count) {

        if (count > 0) {

            if (!productMap.containsKey(nameProduct)) {
                productMap.put(nameProduct, new Product(nameProduct.name(), weight, count));
            }
            else {
                Product product = productMap.get(nameProduct);
                product.setCount(product.getCount() + count);
            }
        }
        else {
            throw new RuntimeException("count can not be negative .. ");
        }

    }


    public void saleProduct(NameProduct nameProduct, double weight, int count) {

        Product product = productMap.get(nameProduct);

        if (count > 0 && count <= product.getCount()) {

            if (productMap.containsKey(nameProduct) && (product.getWeight() == weight)) {
                product.setCount(product.getCount() - count);
            }
            else {
                throw new RuntimeException("product or weight is  incorrect");
            }

        }
        else {
            throw new RuntimeException("count is incorrect ");
        }

    }


    public void reportStorage() {
        System.out.println("My storage: ");

        productMap.forEach((e1, e2) -> System.out.println(e1 + " : " + e2));
    }
}
