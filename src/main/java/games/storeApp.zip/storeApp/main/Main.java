package games.storeApp.main;

import games.storeApp.enumProduct.NameProduct;
import games.storeApp.shopping.StoreApp;
import games.storeApp.shopping.StoreImpl;

public class Main {
    public static void main(String[] args) {

        StoreApp storeApp = new StoreImpl();
        storeApp.bossBuy();

        storeApp.storageProduct();

        storeApp.saleProduct(NameProduct.SOFA, 3);

        storeApp.storageProduct();

    }
}
