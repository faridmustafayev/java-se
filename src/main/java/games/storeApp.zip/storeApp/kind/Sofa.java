package games.storeApp.kind;

import games.storeApp.product.Product;

public class Sofa extends Product {
    public Sofa(String name, int age) {
        super(name, age);
    }
}
