package games.storeApp2.enumProduct;

public enum NameProduct {
    SOFA, CHAIR, CANDLESTICK;
}
