package games.storeApp.shopping;

import games.storeApp.enumProduct.NameProduct;

public interface StoreApp {
    void buyProduct(NameProduct nameProduct, int count);
    void saleProduct(NameProduct nameProduct, int count);
    void storageProduct();
    void bossBuy();
}
