package lastFullRepeat.storeApp2.enumFor;

public enum ProductType {
    HEADPHONE, PHONE;
}
