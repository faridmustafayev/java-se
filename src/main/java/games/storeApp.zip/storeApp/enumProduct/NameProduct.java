package games.storeApp.enumProduct;

public enum NameProduct {
    SOFA, CHAIR, CANDLESTICK;
}
